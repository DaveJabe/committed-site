Committed press kit / Kit de prensa

fact-sheet/    Descriptions, facts, pricing, platforms, recent releases (English and Spanish)
icons/         App icon: square master (Apple applies the mask), pre-masked with transparency, Mac and Apple Watch
screenshots/   Genuine captures of the app. iPhone: website frames (598 × 1300). Apple Watch: a photo of the watch face complication.
artwork/       Key art and compositions drawn from the app's own designs (widgets, Matrix, Your Sky). "editorial" pieces carry no text.

Everything shows synthetic demonstration data, never a real person's information.
Todo muestra datos de demostración ficticios, nunca información de una persona real.

App Store: https://apps.apple.com/app/id6783140621
